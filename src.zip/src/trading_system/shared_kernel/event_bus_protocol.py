"""
Event Bus Protocol (Interface).

This module defines the contract that all event bus implementations must follow.
Using Python's Protocol (PEP 544) for structural subtyping.

Why Protocol instead of ABC?
- More Pythonic (duck typing) - embraces Python's philosophy of "looks like a duck, quacks like a duck"
- Better type checking with mypy - static type checkers can verify compatibility without runtime overhead
- More flexible (doesn't require explicit inheritance) - third-party implementations work seamlessly
- Industry standard for interfaces in modern Python - widely adopted in libraries like typing_extensions

Protocols enable gradual typing: existing classes automatically satisfy the protocol if they implement
the required methods, making it easier to integrate with legacy code or external libraries. This is
particularly valuable in our trading system where we may need to swap implementations or integrate
with third-party event systems without modifying their code.

However, we'll also provide an ABC version for explicit contracts when you want compile-time
guarantees and clearer inheritance hierarchies.
"""

from typing import Protocol, TypeVar, Callable, Awaitable, Type, Optional
from abc import ABC, abstractmethod

from src.trading_system.shared_kernel.events import BaseEvent


# Generic type for events
# This creates a reusable type variable constrained to BaseEvent and its subclasses.
# Allows type hints like: handler: Callable[[EventType], Awaitable[None]]
# Example: If EventType = OrderCreatedEvent, handler must accept OrderCreatedEvent
EventType = TypeVar('EventType', bound=BaseEvent)


# ============================================================================
# PROTOCOL VERSION (Structural Subtyping - Preferred)
# ============================================================================

class EventBusProtocol(Protocol):
    """
    Protocol for event bus implementations.
    
    Any class that implements these methods satisfies this protocol,
    even without explicit inheritance.
    
    This is structural typing: the protocol checks what methods a class HAS,
    not what it inherits from. If your class has publish(), subscribe(), etc.,
    it's automatically an EventBus—no inheritance needed. This is ideal for
    integrating third-party libraries or mock objects that can't inherit from
    our base classes (for example, a Kafka client or RabbitMQ wrapper can work
    as an EventBus without modification).
    """